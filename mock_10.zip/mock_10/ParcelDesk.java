/** Task 1 public API only. Choose your own fields and supporting classes. */
public class ParcelDesk {
  public ParcelDesk(int capacity) {
    throw new UnsupportedOperationException("TODO: ParcelDesk");
  }

  public String addParcel(String name, int days) {
    throw new UnsupportedOperationException("TODO: addParcel");
  }

  public String allParcels() {
    throw new UnsupportedOperationException("TODO: allParcels");
  }

  public String overdueParcels() {
    throw new UnsupportedOperationException("TODO: overdueParcels");
  }

  public String extend(int index) {
    throw new UnsupportedOperationException("TODO: extend");
  }

  public int totalFees() {
    throw new UnsupportedOperationException("TODO: totalFees");
  }
}
