class WorkshopLine {
}
